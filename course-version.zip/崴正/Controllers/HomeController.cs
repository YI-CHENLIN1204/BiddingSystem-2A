using 崴正.Data;
using 崴正.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using System.Diagnostics;

namespace 崴正.Controllers;

[Authorize]
public class HomeController : Controller
{
    private readonly ILogger<HomeController> _logger;
    private readonly ApplicationDbContext _context;

    public HomeController(ILogger<HomeController> logger, ApplicationDbContext context)
    {
        _logger = logger;
        _context = context;
    }
    [Authorize(Roles = "Estimator,Manager,Admin")]
    public IActionResult Index()
    {
        return View();
    }

    [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
    public IActionResult Privacy()
    {
        return View();
    }

    [HttpGet]
    public IActionResult Error()
    {
        return View();
    }

    // 課程版暫不開放工程估算功能。
    // 產學版未來可將此頁作為 quantity_rule_base 規則表計算引擎入口。
    [Authorize(Roles = "Manager,Admin")]
    public IActionResult EstimationUI()
    {
        return RedirectToAction("Index", "Home");
    }

    [Authorize(Roles = "Procurement,Manager,Admin")]
    public IActionResult UploadFinalBid()
    {
        return View();
    }
}