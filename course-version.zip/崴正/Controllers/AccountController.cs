using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;

namespace 崴正.Controllers;

public class AccountController : Controller
{
    [HttpGet]
    public IActionResult Login(string? returnUrl = null)
    {
        ViewData["ReturnUrl"] = returnUrl;
        return View();
    }

    [HttpPost]
    public async Task<IActionResult> Login(string username, string password, string? returnUrl = null)
    {
        if (password != "1234")
        {
            ViewBag.Error = "帳號或密碼錯誤";
            ViewData["ReturnUrl"] = returnUrl;
            return View();
        }

        string role;

        switch (username)
        {
            case "estimator":
                role = "Estimator";
                break;

            case "procurement":
                role = "Procurement";
                break;

            case "manager":
                role = "Manager";
                break;

            case "admin":
                role = "Admin";
                break;

            default:
                ViewBag.Error = "帳號或密碼錯誤";
                ViewData["ReturnUrl"] = returnUrl;
                return View();
        }

        var claims = new List<Claim>
        {
            new Claim(ClaimTypes.Name, username),
            new Claim(ClaimTypes.Role, role)
        };

        var identity = new ClaimsIdentity(
            claims,
            CookieAuthenticationDefaults.AuthenticationScheme
        );

        var principal = new ClaimsPrincipal(identity);

        await HttpContext.SignInAsync(
            CookieAuthenticationDefaults.AuthenticationScheme,
            principal
        );

        if (!string.IsNullOrEmpty(returnUrl) && Url.IsLocalUrl(returnUrl))
        {
            return Redirect(returnUrl);
        }

        // 依角色導向不同功能頁
        if (role == "Procurement")
        {
            return RedirectToAction("UploadFinalBid", "Home");
        }

        if (role == "Estimator")
        {
            return RedirectToAction("Index", "Home"); // 異常偵測
        }

        if (role == "Manager" || role == "Admin")
        {
            return RedirectToAction("Index", "Home");
        }

        return RedirectToAction("Index", "Home");
    }

    public async Task<IActionResult> Logout()
    {
        await HttpContext.SignOutAsync(
            CookieAuthenticationDefaults.AuthenticationScheme
        );

        return RedirectToAction("Login", "Account");
    }
    
    [HttpGet]
    public IActionResult AccessDenied()
    {
        return View();
    }
}

