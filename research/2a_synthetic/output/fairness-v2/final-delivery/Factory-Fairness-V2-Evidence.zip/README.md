# Factory Fairness V2 完整證據包

- Word 已嵌入八張核心圖。figures 包含 14 組 300 dpi PNG 與 SVG。
- equal_sample_per_case.csv、e3_per_case.csv、dictionary_material_per_case.csv 為原始逐案輸出。其餘 CSV 為完整度、比較、字典及工時推估證據。
- manifest.json 保留來源雜湊和算法凍結設定。SHA256SUMS.json 核對本包實際內容。原始合成來源資料不在本包，須另取得凍結 FACTORY_20261122_V1 來源目錄。
- E2 重現：於 scripts 執行 python replay_factory_equal_n.py <來源> <新目錄>，再執行 python factory_equal_n_bootstrap.py <新目錄>。
- E3 重現：以 replay_factory_b1.py <來源> <evening-root>/factory-b1-past --past-only 生成 B1 輸出。將回溯的 factory_b1_pairs.csv 放入 <evening-root>/factory-b1，以 replay_factory_a1.py <來源> <evening-root>/factory-b1 .3 --past-only 及 .1 --past-only 重播 A0/A1。再跑 factory_e3_summary.py <evening-root> <輸出目錄>。
- 工時是情境推估，正式算法採用維持 A0。B1-K 是控制變體。獨立建案、正式 API 與真人工時仍待驗證。

- 回顧版及時間限制版 B1 原始逐案輸出位於 replay-inputs/factory-b1 與 replay-inputs/factory-b1-past。
