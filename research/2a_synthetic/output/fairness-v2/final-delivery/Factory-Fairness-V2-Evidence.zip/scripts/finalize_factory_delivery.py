"""Package unchanged V2 evidence with embedded, numbered Word figures."""
import hashlib
import json
import re
import shutil
import struct
import zipfile
from pathlib import Path
from xml.etree import ElementTree as ET
from xml.sax.saxutils import escape

source=Path("deliverables/factory-fairness-v2")
dest=Path("deliverables/Factory-Fairness-V2-Final")
dest.mkdir(exist_ok=True)
charts=dest/"figures"
charts.mkdir(exist_ok=True)
figures=[
    ("01-e1","E1 同參考案區間分數。26 案、78 案項，兩法共用八件參考案與權重。"),
    ("02-e2-k5","E2 K5 等樣本控制比較。混凝土 6 案、鋼筋 6 案、結構體金額 18 案共同可估。"),
    ("02-e2-k8","E2 K8 等樣本控制比較。混凝土與鋼筋各僅 1 案共同可估，金額有 15 案。數量只作個案觀察。"),
    ("03-e3-score","E3 完整方法區間分數。混凝土 6 案、鋼筋 6 案、金額 18 案共同可估。"),
    ("03-e3-available","E3 完整方法可估案數。各工項以 26 件測試案為分母。"),
    ("05-dictionary-guard","字典規則的放行與待審。26 件合成廠房共 3,386 列，保守規則放行 207 列。"),
    ("06-labor-500","500 列標單工時情境。使用 26 案共 3,386 列推算放行比例，比較攤提 1 份與 20 份。"),
    ("07-time","E1 日期限制敏感度。回溯版 78 案項，較早開工版 60 案項。開工日作為可用日期的代理。"),
]
for f in source.iterdir():
    if f.suffix in (".png",".svg"):
        shutil.copyfile(f,charts/f.name)
    elif f.suffix in (".csv",".json"):
        shutil.copyfile(f,dest/f.name)
with zipfile.ZipFile(source/"Factory-Fairness-Report-ZH.docx") as z:
    parts={n:z.read(n) for n in z.namelist()}
xml=parts["word/document.xml"].decode()
xml=xml.replace("<w:document ",'<w:document xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" xmlns:wp="http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing" xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" xmlns:pic="http://schemas.openxmlformats.org/drawingml/2006/picture" ')
def paragraph(value,size=21,keep=False):
    keep_xml="<w:keepNext/>" if keep else ""
    return f'<w:p><w:pPr>{keep_xml}<w:spacing w:after="120"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Calibri" w:eastAsia="Microsoft JhengHei"/><w:sz w:val="{size}"/></w:rPr><w:t>{escape(value)}</w:t></w:r></w:p>'
break_page='<w:p><w:r><w:br w:type="page"/></w:r></w:p>'
content=[]
links=[]
markdown=[]
for i,(name,caption) in enumerate(figures,1):
    if i%2==1:
        content.extend((break_page,paragraph("核心比較圖表",30,True)))
    png=(charts/(name+".png")).read_bytes()
    w,h=struct.unpack(">II",png[16:24])
    cx=5700000
    cy=round(cx*h/w)
    rid=f"rId{i}"
    parts[f"word/media/{name}.png"]=png
    links.append(f'<Relationship Id="{rid}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/image" Target="media/{name}.png"/>')
    content.append(f'<w:p><w:pPr><w:keepNext/><w:jc w:val="center"/></w:pPr><w:r><w:drawing><wp:inline><wp:extent cx="{cx}" cy="{cy}"/><wp:docPr id="{i}" name="{name}" descr="{escape(caption)}"/><a:graphic><a:graphicData uri="http://schemas.openxmlformats.org/drawingml/2006/picture"><pic:pic><pic:nvPicPr><pic:cNvPr id="{i}" name="{name}.png"/><pic:cNvPicPr/></pic:nvPicPr><pic:blipFill><a:blip r:embed="{rid}"/><a:stretch><a:fillRect/></a:stretch></pic:blipFill><pic:spPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="{cx}" cy="{cy}"/></a:xfrm><a:prstGeom prst="rect"><a:avLst/></a:prstGeom></pic:spPr></pic:pic></a:graphicData></a:graphic></wp:inline></w:drawing></w:r></w:p>')
    label=f"圖 {i}　{caption}"
    content.append(paragraph(label))
    if name.startswith("02-e2"):
        content.append(paragraph("本圖的 B1 為限 K 的 B1-K 控制變體。所有案項均為合成資料。"))
    markdown.append(f"**{label}**\n\n![圖 {i}](figures/{name}.png)")
xml=xml.replace("<w:sectPr>","".join(content)+"<w:sectPr>")
parts["word/document.xml"]=xml.encode()
parts["word/_rels/document.xml.rels"]=('<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'+"".join(links)+'</Relationships>').encode()
parts["[Content_Types].xml"]=parts["[Content_Types].xml"].replace(b"<Override",b'<Default Extension="png" ContentType="image/png"/><Override',1)
for n,data in parts.items():
    if n.endswith((".xml",".rels")):
        ET.fromstring(data)
with zipfile.ZipFile(dest/"Factory-Fairness-Report-ZH.docx","w",zipfile.ZIP_DEFLATED) as z:
    for n,data in parts.items(): z.writestr(n,data)
md=(source/"Factory-Fairness-Report-ZH.md").read_text(encoding="utf8")
(dest/"Factory-Fairness-Report-ZH.md").write_text(md+"\n## 核心比較圖表\n\n"+"\n\n".join(markdown)+"\n",encoding="utf8")
scripts=dest/"scripts"
scripts.mkdir(exist_ok=True)
repo=Path("work/BiddingSystem-2A/research/2a_synthetic/kde_comparison")
for n in ("replay_factory_equal_n.py","factory_equal_n_bootstrap.py","factory_e3_summary.py","replay_factory_b1.py","probe_external_report.py","factory_material_tfidf.py","factory_c1.py","factory_diagnostics_perf.py","replay_factory_dictionary.py","factory_b1_freeze.json","replay_factory_a0_b1.py","replay_factory_a1.py"):
    shutil.copyfile(repo/n,scripts/n)
shutil.copyfile(__file__,scripts/Path(__file__).name)
for folder in ("factory-b1", "factory-b1-past"):
    original=repo.parent/"output/evening-2a"/folder/"factory_b1_pairs.csv"
    frozen=dest/"replay-inputs"/folder/original.name
    frozen.parent.mkdir(parents=True,exist_ok=True)
    shutil.copyfile(original,frozen)
(dest/"README.md").write_text("""# Factory Fairness V2 完整證據包

- Word 已嵌入八張核心圖。figures 包含 14 組 300 dpi PNG 與 SVG。
- equal_sample_per_case.csv、e3_per_case.csv、dictionary_material_per_case.csv 為原始逐案輸出。其餘 CSV 為完整度、比較、字典及工時推估證據。
- manifest.json 保留來源雜湊和算法凍結設定。SHA256SUMS.json 核對本包實際內容。原始合成來源資料不在本包，須另取得凍結 FACTORY_20261122_V1 來源目錄。
- E2 重現：於 scripts 執行 python replay_factory_equal_n.py <來源> <新目錄>，再執行 python factory_equal_n_bootstrap.py <新目錄>。
- E3 重現：以 replay_factory_b1.py <來源> <evening-root>/factory-b1-past --past-only 生成 B1 輸出。將回溯的 factory_b1_pairs.csv 放入 <evening-root>/factory-b1，以 replay_factory_a1.py <來源> <evening-root>/factory-b1 .3 --past-only 及 .1 --past-only 重播 A0/A1。再跑 factory_e3_summary.py <evening-root> <輸出目錄>。
- 工時是情境推估，正式算法採用維持 A0。B1-K 是控制變體。獨立建案、正式 API 與真人工時仍待驗證。
""",encoding="utf8")
with (dest/"README.md").open("a", encoding="utf8") as readme:
    readme.write("\n- 回顧版及時間限制版 B1 原始逐案輸出位於 replay-inputs/factory-b1 與 replay-inputs/factory-b1-past。\n")
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
manifest=json.loads((dest/"manifest.json").read_text(encoding="utf8"))
for name in ("equal_sample_per_case.csv","e3_per_case.csv","dictionary_material_per_case.csv","equal_sample_summary.csv","equal_sample_bootstrap.csv","e3_summary.csv"):
    assert sha(dest/name)==manifest["files"][name]
for png in charts.glob("*.png"):
    assert sha(png)==manifest["files"][png.name]
    assert sha(png.with_suffix(".svg"))==manifest["files"][png.with_suffix(".svg").name]
assert len(list(charts.glob("*.png")))==len(list(charts.glob("*.svg")))==14
files=[f for f in sorted(dest.rglob("*")) if f.is_file() and f.name!="SHA256SUMS.json"]
(dest/"SHA256SUMS.json").write_text(json.dumps({f.relative_to(dest).as_posix():sha(f) for f in files},indent=2),encoding="utf8")
with zipfile.ZipFile(dest/"Factory-Fairness-Report-ZH.docx") as z:
    assert z.testzip() is None
    assert len([n for n in z.namelist() if n.startswith("word/media/")])==8
archive=dest.parent/"Factory-Fairness-V2-Evidence-Final"/"Factory-Fairness-V2-Evidence.zip"
archive.parent.mkdir(exist_ok=True)
with zipfile.ZipFile(archive,"w",zipfile.ZIP_DEFLATED) as z:
    for f in sorted(dest.rglob("*")):
        if f.is_file(): z.write(f,f.relative_to(dest).as_posix())
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    expected=json.loads(z.read("SHA256SUMS.json"))
    assert set(z.namelist())==set(expected)|{"SHA256SUMS.json"}
    for n,h in expected.items(): assert hashlib.sha256(z.read(n)).hexdigest()==h
print(f"PASS: 8 embedded figures, 14 PNG/SVG pairs, {len(expected)+1} verified ZIP members.")
